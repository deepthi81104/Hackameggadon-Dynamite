import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'nonvegmeal_widget.dart' show NonvegmealWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class NonvegmealModel extends FlutterFlowModel<NonvegmealWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
